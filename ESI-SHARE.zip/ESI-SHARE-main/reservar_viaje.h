#ifndef RESERVAR_VIAJE_H_INCLUDED
#define RESERVAR_VIAJE_H_INCLUDED
#include "comprobar_localidad_viaje.h"
#include "preguntar.h"
void reservar_viaje(int );
void cancelar_reserva(int );

#endif // RESERVAR_VIAJE_H_INCLUDED
