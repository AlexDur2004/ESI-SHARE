#ifndef CREAR_VIAJE_H_INCLUDED
#define CREAR_VIAJE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estructuras.h"
#include "leer.h"

void altaViaje(int, int);

#endif
