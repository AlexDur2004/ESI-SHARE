#ifndef COMPROBAR_USUARIO_H_INCLUDED
#define COMPROBAR_USUARIO_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include "estructuras.h"
#include "leer.h"

void acceso(Estr_Usuario *, int);

#endif // COMPROBAR_USUARIO_H_INCLUDED
