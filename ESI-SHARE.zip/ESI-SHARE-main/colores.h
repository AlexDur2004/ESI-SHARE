#ifndef COLORES_H_INCLUDED
#define COLORES_H_INCLUDED

#include <stdlib.h>
#include <windows.h>

void color(int , int);

#endif // COLORES_H_INCLUDED
