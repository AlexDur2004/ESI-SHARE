#ifndef RESERVAR_H_INCLUDED
#define RESERVAR_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estructuras.h"
#include "leer.h"
#include "preguntar.h"
#include "encontrar.h"

void buscadorRutas(char *);
void imprimirPasos(char *, char *, char *);

#endif // RESERVAR_H_INCLUDED
