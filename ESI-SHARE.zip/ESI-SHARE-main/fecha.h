#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "estructuras.h"
#include "leer.h"

void leerFecha(char *, char *, char *); //para leer fecha, hora inic, hora fin.
void actualizarViaje();
void leer_dia(char *); //para leer fecha.

#endif // FECHA_H_INCLUDED
